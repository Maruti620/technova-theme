jQuery(function ($) {
    let page = 1;
    $('#loadmore').on('click', function () {
        $.post(technova_ajax.ajaxurl, {
            action: 'loadmore',
            page: page
        }, function (data) {
            $('#post-container').append(data);
            page++;
        });
    });
});
