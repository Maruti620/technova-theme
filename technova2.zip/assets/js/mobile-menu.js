(() => {
    const menuButton = document.getElementById('mobileMenuBtn');
    const primaryNav = document.getElementById('primaryNav');

    if (menuButton && primaryNav) {
        menuButton.addEventListener('click', () => {
            primaryNav.classList.toggle('hidden');
        });
    }
})();