<?php

/* =========================
   THEME SETUP
========================= */
add_action('after_setup_theme', function () {

  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('custom-logo');

  add_theme_support('html5', [
    'search-form',
    'comment-form',
    'comment-list',
    'gallery',
    'caption',
    'style',
    'script'
  ]);

  register_nav_menus([
    'primary' => 'Primary Menu'
  ]);
});

/* =========================
   ENQUEUE ASSETS
========================= */
add_action('wp_enqueue_scripts', function () {

  wp_enqueue_style(
    'technova-style',
    get_template_directory_uri() . '/assets/css/main.css',
    [],
    filemtime(get_template_directory() . '/assets/css/main.css')
  );

  wp_enqueue_script('dark-mode',
    get_template_directory_uri() . '/assets/js/dark-mode.js',
    [], null, true);

  wp_enqueue_script('progress',
    get_template_directory_uri() . '/assets/js/progress.js',
    [], null, true);

  wp_enqueue_script('toc',
    get_template_directory_uri() . '/assets/js/toc.js',
    [], null, true);

  wp_enqueue_script('mobile-menu',
    get_template_directory_uri() . '/assets/js/mobile-menu.js',
    [], null, true);

  wp_enqueue_script('loadmore',
    get_template_directory_uri() . '/assets/js/loadmore.js',
    ['jquery'], null, true);

  global $wp_query;
  wp_localize_script('loadmore','technova_ajax',[
    'ajaxurl'   => admin_url('admin-ajax.php'),
    'nonce'     => wp_create_nonce('technova-loadmore-nonce'),
    'max_pages' => $wp_query->max_num_pages
  ]);
});

/* =========================
   READING TIME
========================= */
function technova_reading_time(){
  $words = str_word_count(strip_tags(get_the_content()));
  return ceil($words/200) . ' min read';
}

/* =========================
   RELATED POSTS
========================= */
function technova_related_posts(){

  $related = get_posts([
    'posts_per_page' => 3,
    'post__not_in'   => [get_the_ID()],
    'category__in'   => wp_get_post_categories(get_the_ID())
  ]);

  if($related){
    echo '<h3 class="mt-12 text-2xl font-bold">Related Reading</h3><ul class="mt-4 space-y-2">';
    foreach($related as $r){
      echo '<li><a class="text-indigo-600 hover:underline" href="'.get_permalink($r).'">'.$r->post_title.'</a></li>';
    }
    echo '</ul>';
  }
}

/* =========================
   AJAX LOAD MORE
========================= */
function technova_loadmore(){

  $paged = $_POST['page'] + 1;

  $query = new WP_Query([
    'post_type'=>'post',
    'paged'=>$paged
  ]);

  if($query->have_posts()):
    while($query->have_posts()): $query->the_post();
      get_template_part('template-parts/card');
    endwhile;
  endif;

  wp_die();
}
add_action('wp_ajax_loadmore','technova_loadmore');
add_action('wp_ajax_nopriv_loadmore','technova_loadmore');

/* =========================
   ARTICLE SCHEMA
========================= */
add_action('wp_head',function(){
  if(!is_single()) return;

  echo '<script type="application/ld+json">'.json_encode([
    "@context"=>"https://schema.org",
    "@type"=>"BlogPosting",
    "headline"=>get_the_title(),
    "datePublished"=>get_the_date('c'),
    "dateModified"=>get_the_modified_date('c'),
    "author"=>["@type"=>"Person","name"=>get_the_author()],
    "publisher"=>["@type"=>"Organization","name"=>get_bloginfo('name')]
  ]).'</script>';
},30);
