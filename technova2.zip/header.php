<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="max-image-preview:large">
<?php wp_head(); ?>
</head>

<body <?php body_class('bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100'); ?>>

<div id="progressBar" class="fixed top-0 left-0 h-1 bg-gradient-to-r from-indigo-600 to-cyan-500 z-50"></div>

<header class="sticky top-0 z-50 backdrop-blur-lg bg-white/70 dark:bg-slate-900/70 border-b border-slate-200 dark:border-slate-700">

<div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

  <a href="<?php echo home_url(); ?>" class="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-cyan-500 bg-clip-text text-transparent">
    <?php bloginfo('name'); ?>
  </a>

  <nav id="primaryNav" class="hidden absolute top-full left-0 w-full bg-white/95 dark:bg-slate-900/95 p-4 md:p-0 md:static md:w-auto md:bg-transparent md:dark:bg-transparent md:flex">
    <?php wp_nav_menu([
      'theme_location'=>'primary',
      'container'=>false,
      'menu_class'=>'flex flex-col md:flex-row gap-4 md:gap-8 font-medium items-center'
    ]); ?>
  </nav>
  
  <div class="flex items-center gap-4">
    <button id="darkToggle" class="text-xl">🌙</button>
    <button id="mobileMenuBtn" class="md:hidden text-2xl">☰</button>
  </div>

</div>

</header>
