<?php get_header(); ?>

<main class="max-w-7xl mx-auto p-6">

<div id="post-container" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
<?php while(have_posts()):the_post();
 get_template_part('template-parts/card');
endwhile; ?>
</div>

<button id="loadmore" class="btn mt-8">Load More</button>

</main>

<?php get_footer(); ?>
