<?php get_header(); ?>

<main class="max-w-4xl mx-auto px-6 py-16">

<h1 class="text-4xl font-bold mb-4"><?php the_title(); ?></h1>

<p class="text-sm text-slate-500 mb-8">
<?php echo technova_reading_time(); ?>
</p>

<div id="toc" class="mb-10 p-6 bg-slate-100 dark:bg-slate-800 rounded-xl"></div>

<div class="prose dark:prose-invert max-w-none">
<?php the_content(); ?>
</div>

<?php
  // Display related posts after the content
  technova_related_posts();

  // If comments are open or there is at least one comment, load up the comment template.
  if ( comments_open() || get_comments_number() ) :
    comments_template();
  endif;
?>

</main>

<?php get_footer(); ?>
